import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CreatePost = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('/api/posts', { title, content });
    navigate('/');
  };

  return (
    <form onSubmit={handleSubmit} className="p-6 space-y-4">
      <h2 className="text-xl font-bold">Create New Post</h2>
      <input type="text" placeholder="Title" className="border p-2 w-full" value={title} onChange={(e) => setTitle(e.target.value)} />
      <textarea placeholder="Content" className="border p-2 w-full" value={content} onChange={(e) => setContent(e.target.value)}></textarea>
      <button type="submit" className="bg-purple-500 text-white px-4 py-2">Submit</button>
    </form>
  );
};

export default CreatePost;