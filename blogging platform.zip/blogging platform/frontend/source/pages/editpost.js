import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const EditPost = () => {
  const { id } = useParams();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`/api/posts/${id}`).then(res => {
      setTitle(res.data.title);
      setContent(res.data.content);
    });
  }, [id]);

  const handleUpdate = async (e) => {
    e.preventDefault();
    await axios.put(`/api/posts/${id}`, { title, content });
    navigate('/');
  };

  return (
    <form onSubmit={handleUpdate} className="p-6 space-y-4">
      <h2 className="text-xl font-bold">Edit Post</h2>
      <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} className="border p-2 w-full" />
      <textarea value={content} onChange={(e) => setContent(e.target.value)} className="border p-2 w-full"></textarea>
      <button type="submit" className="bg-yellow-500 text-white px-4 py-2">Update</button>
    </form>
  );
};

export default EditPost;
