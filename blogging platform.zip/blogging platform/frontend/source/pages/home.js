import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Home = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios.get('/api/posts').then(res => setPosts(res.data));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">All Blog Posts</h1>
      <Link to="/create" className="text-blue-500 underline">Create New Post</Link>
      <ul className="mt-4 space-y-4">
        {posts.map(post => (
          <li key={post._id} className="border p-4 rounded">
            <h2 className="text-xl font-semibold">{post.title}</h2>
            <p>{post.content}</p>
            <Link to={`/edit/${post._id}`} className="text-blue-600 text-sm">Edit</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;