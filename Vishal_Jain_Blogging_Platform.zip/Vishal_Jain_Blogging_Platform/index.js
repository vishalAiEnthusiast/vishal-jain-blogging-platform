const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static("public"));
app.set("view engine", "ejs");

const dataPath = "./data/posts.json";

// Load posts
function loadPosts() {
  try {
    return JSON.parse(fs.readFileSync(dataPath));
  } catch {
    return [];
  }
}

// Save posts
function savePosts(posts) {
  fs.writeFileSync(dataPath, JSON.stringify(posts, null, 2));
}

// Routes
app.get("/", (req, res) => {
  const posts = loadPosts();
  res.render("index", { posts });
});

app.get("/new", (req, res) => {
  res.render("new");
});

app.post("/new", (req, res) => {
  const posts = loadPosts();
  posts.push({ title: req.body.title, content: req.body.content });
  savePosts(posts);
  res.redirect("/");
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));