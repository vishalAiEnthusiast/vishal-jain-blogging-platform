# Vishal Jain Blogging Platform

A simple blogging web application made using Node.js and Express.js.

## Features

- View all blog posts
- Add a new blog post
- Minimal frontend using EJS

## How to Run

1. Install dependencies:

```bash
npm install
```

2. Start the server:

```bash
node index.js
```

3. Visit: `http://localhost:3000`

## Made by Vishal Jain 🚀